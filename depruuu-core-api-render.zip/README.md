# ୨୧ Depruuu Core API

Backend + Discord bot for the Depruuu Core community website.

## 1. What this system does

- Connects a Discord bot to one Discord server.
- Provides member data through a REST API.
- Shows ONLY Discord `online` as Online.
- `idle`, `dnd`, `offline`, or missing presence = Offline.
- Generates member numbers from server join order.
- Provides member ID-card data.
- Detects the newest member through `/api/welcome`.
- Receives reports through `/api/report` and sends them to a Discord webhook.
- Enables CORS for the website.

## 2. Files

- `bot.js` — main server + Discord bot
- `package.json` — dependencies/start command
- `.env.example` — environment variables to create in Render
- `data/` — reserved for future persistent storage

## 3. Discord Developer Portal

Create/use a Discord bot and enable these Privileged Gateway Intents:

- SERVER MEMBERS INTENT
- PRESENCE INTENT

The bot also needs to be invited to the server with at least:

- View Channels
- Read Message History (not required by the API itself, but useful for normal bot operation)
- any permissions your other bot features need

The bot must be a member of the server specified by `DISCORD_GUILD_ID`.

## 4. Render

Create a new Render Web Service from this folder/repository.

Build Command:

```bash
npm install
```

Start Command:

```bash
npm start
```

Environment variables:

```text
DISCORD_TOKEN=your_bot_token
DISCORD_GUILD_ID=your_server_id
REPORT_WEBHOOK_URL=your_report_webhook
```

Do NOT put these secrets in the frontend HTML.

Render automatically supplies `PORT`.

## 5. Test after deployment

Open:

```text
/
```

Then:

```text
/api/health
/api/stats
/api/members
/api/welcome
```

A working `/api/members` response looks like:

```json
{
  "ok": true,
  "members": [],
  "count": 0,
  "updatedAt": "..."
}
```

The array should contain real Discord members when the bot has the required intents and access.

## 6. Important note about member numbers

This version calculates member numbers from current server join order.

If you need numbers that NEVER change after a member leaves/rejoins or after a full Render rebuild, use persistent storage (for example a database or Render persistent disk). This starter version deliberately avoids putting a database credential in the code.

## 7. Frontend API base

Use:

```text
https://YOUR-RENDER-SERVICE.onrender.com
```

Then the frontend can call:

```text
GET /api/stats
GET /api/members
GET /api/members/:id
GET /api/welcome
POST /api/report
```
